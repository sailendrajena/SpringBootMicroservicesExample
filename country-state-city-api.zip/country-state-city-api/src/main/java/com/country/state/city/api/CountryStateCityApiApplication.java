package com.country.state.city.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CountryStateCityApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CountryStateCityApiApplication.class, args);
	}

}
