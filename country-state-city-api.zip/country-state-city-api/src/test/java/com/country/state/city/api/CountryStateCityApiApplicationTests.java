package com.country.state.city.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CountryStateCityApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
