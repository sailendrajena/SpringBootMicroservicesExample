package com.spring.kafka.springkafkaexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringKafkaExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
